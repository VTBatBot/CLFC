#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	pwm_init(); // Need to figure out what the arguments are.
	
	/* Replace with your application code */
	while (1) {
	}
}
